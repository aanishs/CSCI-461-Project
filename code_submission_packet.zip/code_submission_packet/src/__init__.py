"""
Tic Episode Prediction - Hyperparameter Search Framework
"""

__version__ = "0.1.0"
